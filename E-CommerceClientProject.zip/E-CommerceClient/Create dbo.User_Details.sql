﻿USE [Covid_Essentials]
GO

/****** Object: Table [dbo].[User_Details] Script Date: 04-Jun-21 5:59:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

alter TABLE [dbo].[User_Details] (
    [UserId]       INT           IDENTITY (1, 1) NOT NULL,
    [UserName]     VARCHAR (55)  NULL,
    [UserPassword] VARCHAR (55)  NULL,
    [UserEmail]    VARCHAR (55)  NULL,
    [UserContact]  VARCHAR (15)  NULL,
    [UserAddress]  VARCHAR (100) NULL,
    [RoleId]       INT           NULL
);


