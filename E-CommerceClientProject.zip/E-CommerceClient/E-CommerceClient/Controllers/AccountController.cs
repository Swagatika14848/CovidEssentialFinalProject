﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using E_CommerceClient.ViewModels;
using E_CommerceClient.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;

namespace E_CommerceClient.Controllers
{
   
    public class AccountController : Controller
    {
        public readonly UserManager<MyIdentityUser> userManager;//identity Api used for creating and managing users
        public readonly SignInManager<MyIdentityUser> loginManager;//identity Api used for log in user in and out of the system
        public readonly RoleManager<MyIdentityRole> roleManager;//identity Api used for creating and managing  roles

        public AccountController(UserManager<MyIdentityUser> userManager,
            SignInManager<MyIdentityUser> loginManager,
            RoleManager<MyIdentityRole> roleManager)
        {
            this.userManager = userManager;
            this.loginManager = loginManager;
            this.roleManager = roleManager;

            AddAdmin();

        }

        //creating admin details
        private void AddAdmin()
        {

            if (!roleManager.RoleExistsAsync("admin").Result)
            {
                MyIdentityRole role = new MyIdentityRole();
                role.Name = "admin";
                role.Description = "administer web site";
                IdentityResult roleResult = roleManager.CreateAsync(role).Result;
                if (!roleResult.Succeeded)
                {
                    ModelState.AddModelError("", "Error while creating role");

                }
                else
                {

                    MyIdentityUser user = new MyIdentityUser();
                    user.UserName = "admin";
                    user.Email = "admin@test.com";
                    user.FullName = "site admin";

                    IdentityResult result = userManager.CreateAsync(user, "test123").Result;

                    userManager.AddToRoleAsync(user, "admin").Wait();

                }
            }
        }


        //user cannot access admin page
        [HttpGet]
        [AllowAnonymous]
        public IActionResult AccessDenied()
        {
            return View();
        }


        
        [HttpGet]
        public IActionResult Register()
        {

            return View();
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        //user creation,role creation,assign role to user
        public IActionResult Register(RegisterViewModel obj)
        {
            if (ModelState.IsValid)
            {
                MyIdentityUser user = new MyIdentityUser();
                user.UserName = obj.UserName;
                user.Email = obj.Email;
                user.FullName = obj.FullName;
                user.BirthDate = obj.BirthDate;

                IdentityResult result = userManager.CreateAsync(user, obj.Password).Result;
                if (result.Succeeded)
                {
                    if (!roleManager.RoleExistsAsync("NormalUser").Result)
                    {
                        MyIdentityRole role = new MyIdentityRole();
                        role.Name = "NormalUser";
                        role.Description = "Perform normal operations";
                        IdentityResult roleResult = roleManager.CreateAsync(role).Result;

                        if (!roleResult.Succeeded)
                        {
                            ModelState.AddModelError("", "Error while creating Role.!");
                            return View(obj);
                        }


                    }

                    userManager.AddToRoleAsync(user, "NormalUser").Wait();
                    return RedirectToAction("Login", "Account");
                }
                else
                {
                    IEnumerable<IdentityError> errors = result.Errors;
                    foreach (var item in errors)
                    {
                        ModelState.AddModelError("", item.Description);

                    }

                }

            }
            return View(obj);
        }


        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {


            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginViewModel obj)
        {

            if (ModelState.IsValid)
            {
                var result = loginManager.PasswordSignInAsync(obj.UserName, obj.Password, obj.RememberMe, true).Result;

                if (result.Succeeded)
                {
                    return RedirectToAction("Index", "Home"); //valid user

                }
                else
                {
                    ModelState.AddModelError("validmsg", "Invalid login.!");//invaliduser

                }

                if (result.IsLockedOut)
                {
                    ModelState.AddModelError("validmsg", "Account is locked");

                }

            }
            return View(obj); //failing server side validation
        }

        public IActionResult LogOff()
        {
            loginManager.SignOutAsync().Wait();
            return RedirectToAction("Index", "Home");
        }

    }
}
