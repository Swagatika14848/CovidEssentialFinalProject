﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace E_CommerceClient.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetUserDetails()
        {
            return View();
        }

        public IActionResult GetOrderDetails()
        {
            return View();
        }
        public IActionResult AddProducts()
        {
            return View();
        }

        public IActionResult DeleteProducts()
        {
            return View();
        }

        public IActionResult UpdateProducts()
        {
            return View();
        }
    }
}
