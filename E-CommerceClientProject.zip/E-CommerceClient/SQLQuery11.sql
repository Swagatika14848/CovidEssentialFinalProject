﻿select * from [dbo].[Order_Details]
select * from [dbo].[Product_Details]
select * from [dbo].[User_Details]
select * from [dbo].[User_Role]