﻿select * from [dbo].[AspNetUsers]

