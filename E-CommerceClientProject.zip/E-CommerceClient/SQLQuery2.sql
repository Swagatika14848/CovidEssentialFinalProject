﻿select * from [dbo].[User_Details]
DELETE FROM [dbo].[User_Details] 
WHERE UserId = 8;

Insert into User_Details(UserName, UserPassword, UserEmail, UserContact, UserAddress,RoleId)values
('Swagatika','Swgatika@1998','swagatika@gmail.com',8805989252,'odisa',1);

DELETE FROM [dbo].[User_Details];

[dbo].[User_Details]

rollback;