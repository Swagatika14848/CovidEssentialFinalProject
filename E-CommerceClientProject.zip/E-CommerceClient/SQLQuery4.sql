﻿select * from [dbo].[User_Details]
select * from [dbo].[Product_Details]