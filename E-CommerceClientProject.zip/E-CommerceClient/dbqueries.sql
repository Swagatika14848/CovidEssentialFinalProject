﻿select * from [dbo].[Order_Details]
select * from [dbo].[Product_Details]
select * from [dbo].[User_Details]
select * from [dbo].[User_Role]

select * from [dbo].[Product_Details]
delete from [dbo].[Product_Details] where ProductId=26

delete from [dbo].[User_Details] where UserId=6



Insert into Product_Details(ProductName, ProductDescription, Price, ProductQuantity, ImageUrl)values
('Latex Medical Examination Disposable Hand Gloves (Pack of 20 Pcs)',
'Hospital, dental, laboratory, food and industrial use
Single use disposable for multi purpose',
239.00, 12 ,'https://images-na.ssl-images-amazon.com/images/I/51%2BIZ43LgnL._SL1000_.jpg'),

('Lizol Disinfectant Surface & Floor Cleaner Liquid, Floral - 2 L|Kills 99.9% Germs',
'India No.1 Floor Cleaning Brand, Recommended by the Indian Medical Association',
332.73,26,
'https://images-na.ssl-images-amazon.com/images/I/61pY%2B%2BN4XFL._SL1000_.jpg'),


('TRENDBUY Face, Nose, Cold and Cough Steamer 3 in 1 Plastic Steam',
'Nose is provided to promote relief from cold, throat infection and congestion problems. You can add to the vaporizers like balm and other medicines [Enhances beauty]- can be used for beauty purpose.',
300.00,60,'https://images-na.ssl-images-amazon.com/images/I/614GkZ4vZdS._SL1500_.jpg'),


('Trycone Immunity Booster – Natural Vitamin C 1000 mg with Zinc 12 mg',
'Quality Product- It is made of Natural Vitamin C 1000 mg derived from citrus fruits like Amla, Orange etc and Zinc 12 mg, which makes it a complete immunity boosters for adults ',
599.00, 82,'https://images-na.ssl-images-amazon.com/images/I/61tvxtQdoaL._SL1100_.jpg'),


('Tortal Protection Kit',
'three in one total protection kit ',
300.00, 10,'https://rukminim1.flixcart.com/image/416/416/ko0d6kw0/all-purpose-cleaner/f/8/h/total-protection-kit-2000-ml-pack-of-4-hand-and-body-protection-original-imag2k94a6c9uyp3.jpeg?q=70');


https://images-na.ssl-images-amazon.com/images/I/51GdsEC14VS._SL1280_.jpg