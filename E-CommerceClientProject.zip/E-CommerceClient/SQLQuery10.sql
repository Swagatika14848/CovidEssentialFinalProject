﻿select * from [dbo].[AspNetRoles]
select * from [dbo].[AspNetUsers]