﻿select * from [dbo].[Product_Details]



Insert into Product_Details(ProductName, ProductDescription, Price, ProductQuantity, ImageUrl)values
('Mask Image new',
'MaskImage',
489.00, 35 ,'C:/Users/DELL/source/repos/E-CommerceClient/E-CommerceClient/wwwroot/lib/Images/image6.jpg');