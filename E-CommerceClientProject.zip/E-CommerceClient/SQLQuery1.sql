﻿select * from User_details
delete from user_details where userid=7